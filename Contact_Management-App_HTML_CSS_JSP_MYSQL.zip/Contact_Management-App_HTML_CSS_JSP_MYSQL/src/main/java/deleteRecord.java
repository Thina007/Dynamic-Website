import java.io.PrintWriter;
import java.io.IOException;
import database.com.demo.LoginDao;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/deleterecord")
public class deleteRecord extends HttpServlet{

	
	public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException
	{
		res.setHeader("cache-Control","no-cache,no-store,must-revalidate");
		
		LoginDao lg= new LoginDao();
		HttpSession session = req.getSession();
		String tname=(String)session.getAttribute("name");
		String name=req.getParameter("name");
		
		if(lg.deleteRecord(tname,name))
		{
			res.sendRedirect("welcome.jsp");
		}
		else
		{
			PrintWriter out=res.getWriter();
			out.println("Some Thing Went Worng Could Not able to Delete The User !!!");
		}
	}
}
