import java.io.PrintWriter;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;
import database.com.demo.LoginDao;



@WebServlet("/deleteaccount")
public class deleteAccount extends HttpServlet{

	
	public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException
	{
		res.setHeader("cache-Control","no-cache,no-store,must-revalidate");
		
		LoginDao lg= new LoginDao();
		HttpSession session = req.getSession();
		String tname=(String)session.getAttribute("name");
		if(lg.deleteUserAccount(tname))
		{
			lg.deleteAccount(tname);
			res.sendRedirect("index.jsp");
		}
		else
		{
			PrintWriter out=res.getWriter();
			out.println("Some Thing Went Worng Could Not able to Delete The User !!!");
		}
	}
}
