package com.demo;

import java.io.IOException;

import java.io.PrintWriter;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import database.com.demo.LoginDao;

@WebServlet("/login")
public class login  extends HttpServlet{
	public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException
	{
		
		LoginDao ld= new LoginDao();
		res.setHeader("cache-Control","no-cache,no-store,must-revalidate");
		String name=req.getParameter("uname");
		name=name.toLowerCase();
		String pass =req.getParameter("pass");
		
		if(!ld.checkUser(name))
		{
			PrintWriter out=res.getWriter();
			out.println("User Not Found Please Signup :)");
		}
		else if(ld.check(name,pass))
		{
			HttpSession session =req.getSession();
			session.setAttribute("name", name);
			session.setAttribute("pass", pass);
			res.sendRedirect("welcome.jsp");
		}
		else
		{
			
			PrintWriter out=res.getWriter();
			out.println("Password is Incorrect !!!");
		}
	}
}


