package database.com.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginDao {
	
	 String url = "jdbc:mysql://localhost:3306/minProject";
	 String username = "root";
	 String password = "thina33";

	 Connection con;
	public void common() 
	{
		 try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url,username, password);
		} catch (Exception e) {}
		 
	}
	public boolean check(String name,String pass) 
	{
		try {
			String sql =  "select * from customer where name='"+name+"' and password='"+pass+"'";
			common();
			PreparedStatement st=con.prepareStatement(sql);
			ResultSet rs=st.executeQuery();
			if(rs.next())
			{
				return true;
			}
		}
		catch(Exception e) {}
		return false;
	}
	
	
    public boolean insertUser(String name,String password)
    {
    	try {
    	String sql =  "insert into customer values('"+name+"','"+password+"')";
    	common();
		PreparedStatement st=con.prepareStatement(sql);
		int rs=st.executeUpdate();
		if(rs!=0)return true;
    	}catch(Exception e) {}
		
    	return false;
    }
    
    public boolean insertUserRecord(String tname,String name,String phone,String mail)
    {
    	try
    	{
    		String sql =  "insert into "+tname+" values('"+name+"','"+phone+"','"+mail+"');";
    		common();
    		PreparedStatement st=con.prepareStatement(sql);
    		int rs=st.executeUpdate();
    		if(rs!=0)return true;
    	}catch(Exception e) {}
    		
    	return false;
    }
    

	public boolean createTable(String name) {
		
		try
		{
			String sql="Create table "+name+"(name varchar(30) PRIMARY KEY,phonenumber varchar(30),mail varchar(30));";
			common();
			PreparedStatement st = con.prepareStatement(sql);
			st.execute(sql);
			
		}catch(Exception e) {};
		return true;
	}
	public boolean editForm(String tname,String name, String phonenumber, String mail) {
		
		try
		{
			String sql="UPDATE "+tname +" SET mail='"+mail+"',phonenumber="+phonenumber+" WHERE name='"+name+"';";
			common();
			PreparedStatement st = con.prepareStatement(sql);
			int n=st.executeUpdate(sql);
			if(n!=0)return true;
		}
		catch(Exception e) {}
		
		return false;
	}
	public boolean deleteRecord(String tname, String name) {
		try
		{
			String sql="Delete from "+tname +" WHERE name='"+name+"';";
			common();
			PreparedStatement st = con.prepareStatement(sql);
			int n=st.executeUpdate(sql);
			if(n!=0)return true;
		}
		catch(Exception e) {}
		
		return false;
	}
	
	public ResultSet viewAllRecord(String name)
	{
		try {
		String sql="Select * from "+name;
		common();
		PreparedStatement st=con.prepareStatement(sql);
		ResultSet rs=st.executeQuery();
		return rs;
		}catch(Exception e) {};
		return null;
	}
	public boolean deleteAccount(String tname) {
		try
		{
			String sql="Drop table "+tname+";";
			common();
			PreparedStatement st = con.prepareStatement(sql);
			int n=st.executeUpdate();
			if(n!=0)return true;
		}
		catch(Exception e) {}
		
		return false;
	}
	public boolean deleteUserAccount(String tname) {
		try
		{
			String sql="delete from customer where name='"+tname+"';";
			common();
			PreparedStatement st = con.prepareStatement(sql);
			int n=st.executeUpdate();
			if(n!=0)return true;
		}
		catch(Exception e) {}
		
		return false;
	}
	public boolean checkUser(String name) {
		try
		{
			String sql="select * from customer where name='"+name+"';";
			common();
			PreparedStatement st =con.prepareStatement(sql);
			ResultSet rs=st.executeQuery();
			if(rs.next())return true;
		}
		catch(Exception e) {}
		return false;
	}
}
