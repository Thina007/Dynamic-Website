import java.io.IOException;
import database.com.demo.LoginDao;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/userrecord")
public class UserRecord  extends HttpServlet{

	
	public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException
	{
		res.setHeader("cache-Control","no-cache,no-store,must-revalidate");
		LoginDao lg= new LoginDao();
		HttpSession session = req.getSession();
		String tname=(String)session.getAttribute("name");
		String name=req.getParameter("name");
		String phonenumber =(req.getParameter("phone"));
		String mail=req.getParameter("mail");
		
		if(lg.insertUserRecord(tname,name,phonenumber,mail))
		{
			res.sendRedirect("welcome.jsp");
		}
		else
		{
			res.sendRedirect("Duplicate_Contact.jsp");
		}
	}
}
