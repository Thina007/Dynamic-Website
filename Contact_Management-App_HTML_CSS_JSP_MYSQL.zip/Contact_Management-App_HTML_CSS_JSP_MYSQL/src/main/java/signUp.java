
import java.io.IOException;
import java.io.PrintWriter;

import database.com.demo.LoginDao;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/signup")
public class signUp  extends HttpServlet{

	
	public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException
	{
		res.setHeader("cache-Control","no-cache,no-store,must-revalidate");
		LoginDao lg= new LoginDao();
		
		String name=req.getParameter("name");
		String pass =req.getParameter("password");
		name=name.toLowerCase();
		if(lg.insertUser(name,pass))
		{
			if(lg.createTable(name))
			{
				res.sendRedirect("index.jsp");
			}
			else {
				PrintWriter out=res.getWriter();
				out.println("Some Thing Went Worng Try Again !!!");
			}	
		}
		else
		{
			res.sendRedirect("Duplicate_User.jsp");
		}
	}
}
